@echo off
setlocal enabledelayedexpansion
title Launch WCF Test Client

echo ==================================================
echo         WCF Test Client Auto-Launcher
echo ==================================================
echo.
echo Scanning system for Microsoft Visual Studio...
echo.

:: Try to find using vswhere (included in VS 2017+)
set "VswherePath=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"

if exist "%VswherePath%" (
    for /f "usebackq tokens=*" %%i in (`"%VswherePath%" -latest -products * -requires Microsoft.VisualStudio.Component.Wcf.Tooling -property installationPath`) do (
        set "VSPath=%%i"
        set "WcfPath=!VSPath!\Common7\IDE\WcfTestClient.exe"
        
        if exist "!WcfPath!" (
            echo Success! Found WCF Test Client dynamically at:
            echo !WcfPath!
            echo.
            echo Launching...
            start "" "!WcfPath!"
            exit /b
        )
    )
)

:: If vswhere fails or isn't installed, check fixed fallback paths
echo Primary scan did not find the executable. Checking fallback locations...
set "CommonPaths="C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\WcfTestClient.exe" "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\WcfTestClient.exe" "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\WcfTestClient.exe" "C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\Common7\IDE\WcfTestClient.exe" "C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\Common7\IDE\WcfTestClient.exe" "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\IDE\WcfTestClient.exe""

for %%p in (%CommonPaths%) do (
    if exist %%p (
        echo Success! Found WCF Test Client in fallback path:
        echo %%~p
        echo.
        echo Launching...
        start "" %%p
        exit /b
    )
)

:: Failure message
color 0C
echo ERROR: Could not locate WcfTestClient.exe automatically.
echo Please ensure Microsoft Visual Studio is installed on this machine.
echo.
echo Please refer to the WCF_Test_Client_Guide document to locate it manually.
echo.
pause
