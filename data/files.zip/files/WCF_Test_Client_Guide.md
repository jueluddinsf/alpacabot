# WCF Test Client Guidelines

This guide details the steps for migrating from the WCF Storm tool to the Microsoft WCF Test Client for testing WCF Services. The WCF Test Client is a lightweight, built-in tool that allows you to easily input test parameters, submit requests to your WCF service, and view the responses.

## 1. Opening WCF Test Client on Windows

The WCF Test Client (`WcfTestClient.exe`) is typically installed natively alongside Microsoft Visual Studio.

**Method A: Developer Command Prompt (Recommended)**
1. Open the Windows **Start** menu.
2. Search for **Developer Command Prompt for VS** (e.g., "Developer Command Prompt for VS 2022").
3. Launch the application.
4. Type `wcftestclient` and press **Enter**. The WCF Test Client GUI will immediately open.

**Method B: Direct File Path**
If you prefer to create a desktop shortcut or open it directly via Windows Explorer, navigate to your Visual Studio installation path. Since this is a corporate environment, your team is likely using a commercial edition (Professional or Enterprise).

Depending on your installed edition of Visual Studio 2022, check these common locations:
- **Enterprise:** `C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\WcfTestClient.exe`
- **Professional:** `C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\WcfTestClient.exe`
- **Community:** `C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\WcfTestClient.exe`

*(Note: If you are using older versions of Visual Studio, look under `\2019\` or `\2017\` instead of `\2022\`, or under `C:\Program Files (x86)\` for 32-bit installations).*

**How to find your exact path dynamically:**
If you cannot locate the file in the paths above, you can quickly find it using Windows Search:
1. Open the Windows **Start** menu.
2. Search for `WcfTestClient`.
3. Right-click the search result and select **Open file location** to find exactly where it is installed natively on your machine.

**Method C: Creating a Windows Desktop Shortcut**
For daily use, creating a shortcut on your desktop is the most convenient method:
1. Right-click anywhere on your Windows **Desktop**.
2. Select **New** > **Shortcut**.
3. Paste the exact file path to your Visual Studio installation into the box (e.g., `"C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\WcfTestClient.exe"`) and click **Next**.
4. Name the shortcut **WCF Test Client** and click **Finish**.

**Method D: Automated Launch Script (Easy Mode)**
If QA Leadership provided you with the `Launch_WCF_Test_Client.bat` file:
1. Simply drag the `.bat` file to your desktop.
2. Double-click it whenever you need to test. 
3. It will automatically scan your PC for Visual Studio and instantly launch the Test Client for you without any path hunting.

## 2. Setting Up and Adding a Service

Once the WCF Test Client is open, you can add your service to begin testing.

1. Go to **File** > **Add Service** (or right-click "My Service Projects" in the left panel and select Add Service).
2. Enter the **Endpoint Address** of your WCF service (e.g., `http://localhost:8080/MyService.svc` or a `net.tcp://` endpoint) and click **OK**.
3. The tool will parse the service metadata and display the available operations in the left pane.

## 3. Configuring for Large Requests

By default, WCF Test Client imposes a strict size limit (`65,536 bytes` or 64 KB) on incoming and outgoing network messages. When testing with large JSON/XML payloads or arrays, this will result in a quota exception. 

Follow these steps to increase the size limit using the built-in Service Configuration Editor:

### Step 3.1: Edit the Configuration
1. In the left panel, expand your service tree until you see the **Config File** node at the very bottom.
2. Right-click the **Config File** node and select **Edit with SvcConfigEditor**. This opens the WCF Service Configuration Editor tool.
3. In the Configuration Editor's left panel, expand the **Bindings** folder.
4. Select the binding used by your service (e.g., under `basicHttpBinding` or `netTcpBinding`, select the specific generated binding configuration).
5. In the right property panel, locate **MaxReceivedMessageSize** and change its value to something large enough, such as `2147483647` (2 GB). 
   > [!TIP]
   > Also update **MaxBufferSize** and **MaxStringContentLength** / **MaxArrayLength** (found under `ReaderQuotas`) to `2147483647` to avoid other size-related constraint errors during deserialization.
6. Go to **File** > **Save**, then close the Configuration Editor.

### Step 3.2: Prevent Config Overwrites
By default, reloading a service or reopening the client will wipe out any manual configuration changes you just made and revert to the default 64KB sizes. To persist your changes:
1. In the main WCF Test Client window, click on **Tools** > **Options**.
2. **Uncheck** the box that says `"Always regenerate config when launching services"`.
3. Click **OK**.

You can now invoke operations with large request payloads.

## 4. Executing Tests
1. Double-click the desired operation from the left pane. This opens a new test tab.
2. In the **Request** pane on the right, fill out the required parameters for the service call. You can change values, select list sizes, or set objects to null.
3. Click the **Invoke** button.
4. View the result or any generated exceptions in the **Response** pane.

> [!NOTE]
> Ensure that the WCF service server itself also has its `web.config` or `app.config` updated to allow large `MaxReceivedMessageSize` limits. If the server rejects the request natively, configuring the client won't bypass backend limitations!
